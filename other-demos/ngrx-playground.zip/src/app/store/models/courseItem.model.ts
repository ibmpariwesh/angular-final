export interface CourseItem {
  id: string;
  department: string;
  name: string;
}
